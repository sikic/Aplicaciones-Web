function sequence(a, x) {

    let error = false;
    for (let index = 0; index < a.length && !error; index++) {
        let aux = a[index](x);
        if (typeof (aux) === "undefined")
            error = true;

        console.log(aux);
    }

}

let luis = [f1, f2, f4, f3];

function f1(x) {
    return x + 1;
}

function f2(x) {
    return x * 2;
}

function f3(x) {
    return x - 1;
}
function f4(x) {
    return undefined;
}

//ejercicio de clase para ver tamaño de un array de strings
function maplengths(a) {
    let x = [];
    for (let index = 0; index < a.length; index++) {
        x[index] = a[index].length;
    }
    return x;
}

//forma pro con funciones de transformacion
function maplengths2(a) {
    return a.map(n=> n.length);
}

let ar = ["hola", "ey", "fran", "cacaca"];
console.log(maplengths2(ar));

//funcion que separa el array por la mitad u lo devuelve    
function filterInf(a) {
    let x = a.slice(0, a.length / 2);
    return x;
}

//forma pro con funciones de filtrado
function filterInf2(a) {
    //siempre hay que usaar los 3 por que te reconoce lo que es cada uno segun la posicion donde lo situes
    //pero los nombre si que los puedes cmabiar
    return a.filter((n,i,a)=> i < a.length / 2);
}
console.log(filterInf2(ar));



//Te dice si todo es una funcion o no
function everyFunction(a) {
    let error = true;
    for (let index = 0; index < a.length; index++) {
        let aux = a[index];
        if (aux instanceof Function == false)
            error = false;
    }

    if (a.length == 0)
        return false;

    return error;
}

//misma funcion de forma pro con funcion de reduccion
function everyFunction2(a) {
    return a.every(n =>  n instanceof Function);
}
//similar que la de arriba pero jugando con los parametros
//v es el elemento del vector
//i es el indice 
//a es el vector en si 
function everyFunction3(a) {
    return a.every((v,i,a)=>a[i] instanceof Function);
}
let frann = [f1, f4, f3];
console.log(everyFunction3(frann));

//
function someUndefinded(a) {
    let error = false;
    for (let index = 0; index < a.length && !error; index++) {
        let aux = a[index];
        if (typeof (aux) == "undefined")
            error = true;
    }
    return error;
}

//modo pro con las funciones de reduccion
function someUndefinded2(a) {
    return a.some(n => typeof(n) == "undefined");
}
console.log(someUndefinded2(frann));

//usando map y reduce
function reduceSquare(a) {
    let suma = a.map(n => n * n).reduce((ac, n) => ac + n, 0);
    return suma;
}
//usando solo reduce
function reduceSquare2(a) {
    let suma = a.reduce((ac, n) => ac + n * n, 0);
    return suma;
}
let suma = [1, 2, 3];
console.log(reduceSquare2(suma));

// personas.forEach(p => {
//     console.log("Hola, me llamo " + p.nombre
//         + " y tengo " + p.edad + " años");
// })

/*personas.forEach((v, i, a) => {
    console.log("Hola,me llamo " + v.nombre
        + " y tengo " + v.edad + " años"
        + " y soy el " + i + " de un array de "
        + a.length + " elementos");
})*/

function pluck(o,f){
    return o.map(n=>n[f]).filter(n=> typeof(n) != "undefined");
}

function partition(a,p){
    let ar=[];
    ar.push(a.filter(p));
    ar.push(a.filter(p));

    return ar;
}

function groupBy(a,f){
    ar = a.map(f);
    y= a.filter(n => a.indexOf(ar));
    return y;
}


let personas = [
    {nombre: "Ricardo", edad: 63},
    {nombre: "Paco", edad: 55},
    {nombre: "Enrique", edad: 32},
    {nombre: "Adrián", edad: 34},
    {apellido: "García", edad: 28}
    ];
console.log(pluck(personas,"nombre"));    

console.log(partition(personas, pers => pers.edad >= 60));
console.log(groupBy(["Mario", "Elvira", "María", "Estela", "Fernando"],str => str[0]));
